@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
title AgentSelfSave
echo Working directory: %cd%
echo Locker txt must match the agent name, e.g. .Secret\Bogelstein.txt
echo.

set "PYEXE=python"
set "PYARGS="
where python >nul 2>&1
if errorlevel 1 (
  where py >nul 2>&1
  if errorlevel 1 (
    echo python was not found on PATH.
    echo Open a terminal in this folder and run: python prepare_agent.py
    echo.
    pause
    exit /b 1
  )
  set "PYEXE=py"
  set "PYARGS=-3"
)

%PYEXE% %PYARGS% -u prepare_agent.py
echo.
echo Exit code: %ERRORLEVEL%
echo.
pause
