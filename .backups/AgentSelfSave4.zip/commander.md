# commander.md

This file is not a paste.

After `Start_config.bat` or `prepare_agent.py`:

- First save, once: the text printed on screen. Not a file. Do not save it.
- Later new chats: `Revive.md`

Process sheet: `COMMANDERMANUAL.md`.
